package FibonacciFatorial;

public class Teste {
	
	public static void main(String[] args) {
	
		FibonacciFatorial ff = new FibonacciFatorial();
	
		ff.fatorial(5);
		ff.fibonacci(20);
	
	}
}