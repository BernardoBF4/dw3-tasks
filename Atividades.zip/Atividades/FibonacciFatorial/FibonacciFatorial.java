package FibonacciFatorial;

public class FibonacciFatorial {
	
	void fatorial(int n) {	
		int fatorial = 1;
		
		for (int m = 1; m <= n; m++) {
			fatorial *= m;
		}
		
		System.out.println("Fatorial: " + fatorial);
	}
		
	void fibonacci(int n) {
		int n1 = 0, n2 = 1, fibonacci= 0;
		
		for(int m = 1; m <= n; m++){
			System.out.println("Fibonacci: " + fibonacci);
			
			fibonacci = n1 + n2;
			n1 = n2;
			n2 = fibonacci;

		}
	}

}
