package ApostilaCap�tulo4;

public class Exerc�cio8 {
	
	/*
	 O c�digo: "Funcion�rio.salario = 1234;" n�o faz sentido porque a classe define que atributos os 
	 objetos daquele tipo ter�o, ou seja, ela diz que eles v�o exisitir, o que os impede de receber
	 qualquer valor. O erro que aparece quando a execu��o � tentada refere-se � refer�ncia est�tica,
	 classe, para um campo n�o est�tico, que � o salario do funcion�rio.
	  */
	
	/* 
	 O cpodigo: "Fucnionario.calculaGanhoAnual();" tamb�m n�o faz sentido, pois a classe n�o � um
	 objeto para poder ter opera��es feitas sobre ela.
	  */

}
