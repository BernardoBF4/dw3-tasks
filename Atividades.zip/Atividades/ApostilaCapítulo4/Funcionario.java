package ApostilaCapítulo4;

public class Funcionario {
	
	String nome;
	String departamento;
	double salario;
	Data data_entrada = new Data();
	String rg;
	 
	void recebeAumento(double valor_aumento) {
		salario += valor_aumento;
	}
	 
	void calculaGanhoAnual() {
		System.out.println("Este thision�rio ganha " + (salario * 12));
	}
	 
	void mostraAtributos() {
		System.out.println(this.nome);
		this.data_entrada.dataFormatada();
		System.out.println(this.departamento);
		System.out.println(this.salario);
		System.out.println(this.rg);
	}

}
