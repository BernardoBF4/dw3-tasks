package ApostilaCap�tulo4;

public class Data {
	
	int dia;
	int mes;
	int ano;
	
	void dataFormatada() {
		System.out.println("Data de entrada: " + dia + "/" + mes + "/" + ano);
	}

}
