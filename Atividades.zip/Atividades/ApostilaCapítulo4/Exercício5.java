package ApostilaCap�tulo4;

public class Exerc�cio5 {
	
	public static void main(String[] args) {
		
		Funcionario f1 = new Funcionario();
		
		f1.nome = "Geraldo";
		f1.data_entrada.dia = 10;
		f1.data_entrada.mes = 12;
		f1.data_entrada.ano = 2098;
		f1.departamento = "Diretoria";
		f1.salario = 1500;
		f1.rg = "9.342.123.";
		
		Funcionario f2 = f1;
		
		if (f1 == f2) {
			System.out.println("iguais");
		} else {
			System.out.println("diferentes");
		}
		
		
	}

}

//Sa�da: iguais