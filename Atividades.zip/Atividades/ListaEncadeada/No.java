package ListaEncadeada;

public class No {
	
	double valor;
	No proximo;
	No anterior;

}
