package ListaEncadeada;

public class Lista {
	
	int size;
	No primeiro_elemento = new No();

	void append(int valor) {
		No novo_no = new No();
		novo_no.valor = valor;
		No iterador = new No();
		
		if (primeiro_elemento.valor == 0) {
			primeiro_elemento = novo_no;
		} else {
			iterador = primeiro_elemento;
			while (iterador.proximo.valor == 0) {
				iterador = iterador.proximo;
			}
			iterador.proximo = novo_no;
			novo_no.anterior = iterador;
		}
		size += 1;
	}
	
	void imprimir() {
		No iterador = new No();
		
		System.out.println("Lista com " + size + " elementos.");
		iterador = primeiro_elemento;
		int i = 0;
		
		while (iterador.valor == 0) {
			System.out.println("Lista[" + i + "]: " + iterador.valor);
			iterador = iterador.proximo;
			i += 1;
		}
	}

	String get(int indice) {
		No iterador = new No();
		int i = 0;
		
		if (indice > size - 1) {
			return "N�o h� um elemento com este �ndice.";
		}
		iterador = iterador.proximo;
		while (i < indice) {
			iterador = iterador.proximo;
			i += 1;
		}
		return "Seu elemento �: " + iterador.valor;
	}
	
	String pop(int indice) {
		int i = 0;
		indice -= 1;
		No iterador = new No();
		iterador = primeiro_elemento;
		No no = new No();
		No retorno = new No();
		
		if (indice > size) {
			return "N�o h� um elemento com este �ndice";
		} else {
			while (i <= indice){
				iterador = iterador.proximo;
				i += 1;
			}
		}
		no = iterador;
		if (no.valor == 0) {
			return "N�o h� um elemento com este �ndice.";
		}
		retorno = no;
		i = 0;
		iterador = primeiro_elemento;
		while (i <= indice) {
			iterador = iterador.proximo;
			i += 1;
		}
		no = iterador;
		if (no == primeiro_elemento) {
			primeiro_elemento = no.proximo;
			i += 1;
		} else if (no.proximo.valor == 0) {
			no.anterior.proximo.valor = 0;
		} else {
			no.anterior.proximo = no.proximo;
			no.anterior.proximo = no.anterior;
		}
		size -= 1;
		return "O elemento �: " + retorno;
	}
	
}