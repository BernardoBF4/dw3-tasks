package ListaEncadeada;

public class Teste {
	
	public static void main(String[] args) {
	
		Lista lista = new Lista();
	
		lista.append(1);
		lista.append(2);
		lista.append(3);
		lista.append(4);
		
		lista.imprimir();
	}
	
}
